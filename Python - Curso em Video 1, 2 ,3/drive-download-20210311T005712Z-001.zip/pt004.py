print('########### DESAFIO 007 ###########\n')
n1 = int(input('Your first note: '))
n2 = int(input('Your second note: '))
s = n1+n2
print('Your middle is:', s/2)