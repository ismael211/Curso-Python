print('\033[1;33m##### DESAFIO 60 #####\033[m\n')
#fatorial
num = int(input('Digite um número: '))
c = num
fat = 1
while c > 0:
    fat *= c
    c -= 1
print('O resultado de {}! é = {}'.format(num, fat))