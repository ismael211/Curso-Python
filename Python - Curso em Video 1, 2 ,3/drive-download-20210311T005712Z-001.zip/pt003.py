print('########### DESAFIO 006 ###########\n')
n = int(input('Put a number: '))
print('The double is: {}\n The triple is: {}\n The root is: {:.2f}.' .format(n*2, n*3, n**(1/2)))