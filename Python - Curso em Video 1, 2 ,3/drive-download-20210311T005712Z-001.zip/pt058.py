print('\033[1;33m##### DESAFIO 59 #####\033[m\n')
#crie um programa que leia dois valores e veja quais funcionalidades vc quer aplicar
sair = 1
while sair != 5:
    n1 = int(input('Digite um número: '))
    n2 = int(input('Digite outro número: '))
    print('[1] Para somar\n[2] Para multiplicar\n[3] Maior e Menor\n'
          '[4] Digitar os números novamente\n[5] Sair do programa')
    esc = int(input('Escolha um número: '))
    if esc == 1:
        print('A soma de {} mais {} é: {}'.format(n1, n2, n1+n2))
        print('-' * 35)
    elif esc == 2:
        print('{} x {} é igual a: {}'.format(n1, n2, n1*n2))
        print('-' * 35)
    elif esc == 3:
        if n1 > n2:
            print('{} é maior que {}'.format(n1, n2))
            print('-'*35)
        else:
            print('{} é maior que {}'.format(n2, n1))
            print('-' * 35)
    elif esc == 4:
        sair = 1
    elif esc == 5:
        sair = 5