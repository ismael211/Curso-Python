print("###### DESAFIO 30 ######\n")
num = int(input('Digite um numero: '))
par = num%2
if par == 0:
    print('Esse numero é par!')
else:
    print('Esse numero é impar!')