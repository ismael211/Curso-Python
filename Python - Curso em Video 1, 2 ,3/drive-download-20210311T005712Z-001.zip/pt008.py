print('########### DESAFIO 011 ###########\n')
a = float(input('Quantos metros de altura tem a parede? '))
l = float(input('Quantos metros de largura? '))
ar = a*l
ti = ar/2
print('Você vai precisar de {} litros de tinta.'.format(ti))