a="aba"
b="cate"
c=a+b
print(c)