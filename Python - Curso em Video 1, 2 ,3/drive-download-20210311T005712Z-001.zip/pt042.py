print('\033[1;33m##### DESAFIO 44 #####\033[m\n')
val = float(input('Qual o preço do produto? '))
print('''\nCOMO DESEJA PAGAR?
[ 1 ] A vista dinheiro ou cheque
[ 2 ] A vista no cartão
[ 3 ] 2x no cartão
[ 4 ] 3x ou mais no cartão''')
opç = int(input('\nEscolha de 1 a 4: '))
if opç == 1:
    desc = (val*0.10)-val
    print('Com essa forma de pagamento vc tem 10% de desconto. Seu produto custará R${} reais'.format(desc))
elif opç == 2:
    desc = (val*0.05)-val
    print('Com essa forma de pagamento vc tem 5% de desconto. Seu produto custará R${} reais'.format(desc))
elif opç == 3:
    print('Com essa forma de pagamento seu produto custará R${} reais'.format(val))
else:
    desc = (val*0.20)+val
    print('Com essa forma de pagamento seu produto custará R$ {}'.format(desc))