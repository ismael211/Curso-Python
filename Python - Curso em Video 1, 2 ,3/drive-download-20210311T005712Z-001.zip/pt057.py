from random import randint
print('\033[1;33m##### DESAFIO 58 #####\033[m\n')
#melhores o jogo do desafio 28
err = 0
n = 1
num = 0
while n != num:
    n = int(input('Tente advinhar o número de 0 a 5: '))
    num = randint(1, 5)
    if n != num:
        print('Você errou tente novamente. O número era {}'.format(num))
        print('-'*35)
        err += 1
print('VOCÊ ACERTOU! Você precisou de {} tentativas'.format(err))