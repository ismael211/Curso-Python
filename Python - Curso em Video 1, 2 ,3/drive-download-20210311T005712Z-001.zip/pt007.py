print('########### DESAFIO 010 ###########\n')
d = float(input('Quanto dinheiro você tem? R$'))
print('Com R${} você pode comprar US${:.3}'.format(d, d/5.09))