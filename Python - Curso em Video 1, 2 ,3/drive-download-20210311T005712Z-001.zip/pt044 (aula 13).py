from time import sleep
print('\033[1;33m##### DESAFIO 46 #####\033[m\n')
for c in range(10, 0, -1):
    print(c)
    sleep(1)
print('HAPPY NEW YEAR!!!')