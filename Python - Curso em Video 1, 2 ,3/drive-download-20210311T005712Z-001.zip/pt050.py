print('\033[1;33m##### DESAFIO 52 #####\033[m\n')
print('Verificador de números primos.')
num = int(input('Digite um número: '))
if num == 2:
    print('Dois é um número é primo.')
if num == 3:
    print('Três é um número é primo.')
elif num % 2 == 0:
    print('{} não é um número primo.'.format(num))
elif num % 3 == 0:
    print('{} não é um número primo.'.format(num))
else:
    print('{} é um número primo.'.format(num))