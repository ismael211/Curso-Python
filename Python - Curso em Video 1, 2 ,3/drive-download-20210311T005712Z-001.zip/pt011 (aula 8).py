from math import trunc
print('######### DESAFIO 16 #########\n')
n = float(input('Type a real number: '))
print('Esse número inteiro fica {}'.format(trunc(n)))