n = 3 * 5 + 4 ** 2
print(n)