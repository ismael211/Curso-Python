print('\033[1;33m##### DESAFIO 57 #####\033[m\n')
#PROGRAMA Q LEIA SOMENTE M OU F
M = 'M'
F = 'F'
l = 'ç'
while l != M and l != F:
    l = str(input('Qual seu sexo? (F/M) ')).upper()
print('Seu sexo é {}'.format(l))