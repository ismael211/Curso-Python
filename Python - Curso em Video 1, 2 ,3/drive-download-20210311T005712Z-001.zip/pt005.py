print('########### DESAFIO 008 ###########\n')
m = int(input('Digite quantos metros deseja converter: '))
c = m*100
mm = m*1000
print('{} Metros: São {} centimentros. São {} Milimetros.'.format(m, c, mm))