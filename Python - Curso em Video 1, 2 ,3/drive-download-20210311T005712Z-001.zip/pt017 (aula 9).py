frase = (' EU VOU SER PROGRAMADOR ')
#print(frase.replace('PROGRAMADOR', 'GRINGO')) Substituição
#print(frase.count('')) Contar a quantidade de palavras ou letras
#print(frase.upper()) CAPSLOOK
#print(frase.join()) Pra juntar a frase
#print(frase.lower()) Diminutivo
#print(len(frase)) Contar a quantidade de str
#print('EU' in frase) Achar algo
#print(frase.find('')) encontrar a posição
#print(frase.strip()) para eliminar os espaços
print(frase.split()) #Para separar palavras
sepa = frase.split()
print(len(sepa[3]))