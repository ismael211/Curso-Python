print("########## DESAFIO 25 ##########\n")
name = str(input('Digite seu nome: '))
nam = name.upper()
print('SILVA' in nam)
