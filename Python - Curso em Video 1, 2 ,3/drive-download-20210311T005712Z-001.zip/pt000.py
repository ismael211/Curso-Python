n1 = int(input('Put a number: '))
n2 = int(input('Other number: '))
s = (n1+n2)

print('The sum between {} and {} is {}.'.format(n1, n2, s))
