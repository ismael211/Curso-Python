print('\033[1;33m##### DESAFIO 54 #####\033[m\n')
#Quantos já fizeram a maior idade
contma = 0
contme = 0
for c in range(1, 8):
    ano = int(input('Em que ano você nasceu? '))
    idade = 2020 - ano
    if idade >= 21:
        contma += 1
    else:
        contme += 1
print('{} dessas pessoas são maiores de idade'.format(contma))
print('{} dessas pessoas são menores de idade'.format(contme))