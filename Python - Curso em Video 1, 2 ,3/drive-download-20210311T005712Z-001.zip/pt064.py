print('\033[1;33m##### DESAFIO 65 #####\033[m\n')
resp = 'S'
acm = 0
cont = 0
mai = 0
men = 30000
med = 0
while resp in 'S':
    num = int(input('Type a number: '))
    acm += num
    cont += 1
    if cont == 1:
        mai = men = num
    else:
        if num > mai:
            mai = num
        if num < men:
            men = num
    resp = str(input('Prosseguiria? ')).upper().strip()[0]
med = acm/cont
print('A média dos números é: {}'.format(med))
print('O maior valor é {}. O menor é {}'.format(mai, men))