print('########### DESAFIO 012 ###########\n')
s = float(input('Qual seu salario? '))
ns = s*0.15
print('Seu salário com acrescimo de 15% fica {}'.format(ns+s))
