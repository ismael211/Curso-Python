print('########### DESAFIO 011 ###########\n')
p = float(input('Qual o preço do produto? '))
d = p*0.05
print('Esse produto tem {} de desconto, o valor com desconto fica {}'.format(d, p-d))