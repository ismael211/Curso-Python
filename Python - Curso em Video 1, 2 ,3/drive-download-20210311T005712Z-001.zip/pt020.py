print("########## DESAFIO 24 ##########\n")
cid = str(input('Cite uma cidade: ')).strip()
com = cid[0:5]
com = com.upper()
print('SANTO' in com)