print('\033[1;33m##### DESAFIO 47 #####\033[m\n')
#NUMEROS PARES
print('Esses são os numeros pares de 1 a 50.')
for c in range (2, 51, 2):
    print(c)
print('-FIM-')