print('########### DESAFIO 005 ###########\n')
n = int(input('Put a number: '))
print('O antecessor é: {} e o sucessor é: {}'.format(n-1, n+1))