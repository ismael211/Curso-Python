print('\033[1;33m##### DESAFIO 39 #####\033[m\n')
nasc = int(input('Qual seu ano de nascimento? '))
idad = 2020 - nasc
if idad < 18:
    dif = idad - 18
    print('Em menos de {} ano(s) você vai se alistar.'.format(dif))
elif idad == 18:
    print('Já é hora de se alistar.')
else:
    dif = idad - 18
    print('Já fazem {} anos q vc deveria ter se alistado'.format(dif))
