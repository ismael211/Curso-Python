import random
lista = 0
p = 0
lis = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
       22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
       41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60]
for m in range(1, 11):
       a = random.choice(lis)
       b = random.choice(lis)
       c = random.choice(lis)
       d = random.choice(lis)
       e = random.choice(lis)
       f = random.choice(lis)
       lista = [a, b, c, d, e, f]
       #menor
       if a < b and a < c and a < d and a < e and a < f:
              p = a
       elif b < a and b < c and b < d and b < e and b < f:
              p = b
       elif c < a and c < b and c < d and c < e and c < f:
              p = c
       elif d < a and d < b and d < c and d < e and d < f:
              p = d
       elif e < a and e < b and e < c and e < d and e < f:
              p = e
       elif f < a and f < b and f < c and f < d and f < e:
              p = f
       #maior
       if a > b and a > c and a > d and a > e and a > f:
              m = a
       elif b > a and b > c and b > d and b > e and b > f:
              m = b
       elif c > a and c > b and c > d and c > e and c > f:
              m = c
       elif d > a and d > b and d > c and d > e and d > f:
              m = d
       elif e > a and e > b and e > c and e > d and e > f:
              m = e
       elif f > a and f > b and f > c and f > d and f > e:
              m = f

       print('O número sorteado foi: [{}, {}, {}, {}, {}, {}]'.format(p, b, c, d, e, m))
print(lista)