s = input('Type something: ')
print('É número ou letra?', s.isalnum())
print('É apenas número?', s.isnumeric())
print('É apenas letra?', s.isalpha())
